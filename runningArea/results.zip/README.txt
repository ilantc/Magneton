build param = running param = 2000

parallel scanning enabled
